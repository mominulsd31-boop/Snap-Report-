const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 10000;
const DATA_FILE = path.join(__dirname, "data.json");

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname));

function readReports() {
  if (!fs.existsSync(DATA_FILE)) return [];
  try {
    const data = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    return Array.isArray(data) ? data : (data.reports || []);
  } catch {
    return [];
  }
}

function writeReports(reports) {
  fs.writeFileSync(DATA_FILE, JSON.stringify({ reports }, null, 2));
}

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "login.html"));
});

app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "login.html"));
});

app.get("/worker", (req, res) => {
  res.sendFile(path.join(__dirname, "worker.html"));
});

app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "admin.html"));
});

app.get("/api/report", (req, res) => {
  const { date, username } = req.query;
  const reports = readReports();

  const found = reports.filter(r => {
    const sameUser = !username || String(r.username || "").toLowerCase() === String(username).toLowerCase();
    const sameDate = !date || String(r.date || "") === String(date);
    return sameUser && sameDate;
  });

  res.json(found);
});

app.get("/api/reports", (req, res) => {
  res.json(readReports());
});

app.post("/api/reports", (req, res) => {
  const reports = readReports();
  const report = {
    ...req.body,
    createdAt: new Date().toISOString()
  };

  reports.push(report);
  writeReports(reports);
  res.status(201).json({ success: true, report });
});

app.delete("/api/reports", (req, res) => {
  const { date, username } = req.query;
  let reports = readReports();

  reports = reports.filter(r =>
    !(String(r.date || "") === String(date || "") &&
      String(r.username || "").toLowerCase() === String(username || "").toLowerCase())
  );

  writeReports(reports);
  res.json({ success: true });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Snap Report running on port ${PORT}`);
});
